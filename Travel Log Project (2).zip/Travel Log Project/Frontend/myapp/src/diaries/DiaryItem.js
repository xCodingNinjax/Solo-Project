import React, { useState } from "react"
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import Avatar from '@mui/material/Avatar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import EditIcon from '@mui/icons-material/Edit';
import {Box} from "@mui/system"
import { CardActions} from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import EditLocationIcon from '@mui/icons-material/EditLocation';
import {Link} from "react-router-dom"
import {Snackbar,Alert} from "@mui/material"
import { postDelete } from "../api-helpers/helpers";


const DiaryItem = ({title,description,image,location,date,id, user,name}) => {
  const [open, setOpen] = useState(false);
  const isLoggedInUser = () => {
    if(localStorage.getItem("userId") === user){
      return true;
    }
    return false;
};

  const handleDelete = () => {
    postDelete(id)
      .then((data)=> console.log(data))
      .catch((err)=> console.log(err));
    setOpen(true);
  };

    return(
      <Card sx={{width: "50%", height:"auto", margin:1, padding:1, display: 'flex', flexDirection:"column", boxShadow:"5px 5px 10px #ccc" }}>
      <CardHeader
        avatar={
          <Avatar sx={{ bgcolor: "red" }} aria-label="recipe">
            {name}
          </Avatar>
        }
        action={
          <IconButton aria-label="settings">
            {<EditLocationIcon/>}
          </IconButton>
        }
        title={location}
        header={location}
        subheader={date}
      />
      <img
        height="194"
        src={image}
        alt="title"
      />
      <CardContent>
      <Typography paddingBottom={1} variant="h6" color="text.secondary">
          {title}
        </Typography>
        <hr/>
        <Box paddingTop={1} display="flex">
            <Typography paddingTop={1} variant="caption" fontWeight={"bold"} width="170px">{name}:</Typography>
            <Typography paddingTop={1} variant="body2" color="text.secondary">
            {description}
            </Typography>
        </Box>
        </CardContent>
      { isLoggedInUser() && ( 
      <CardActions sx={{marginLeft: "auto"}}>
        <IconButton LinkComponent={Link} to={`/posts/${id}`} color="warning"><EditIcon/></IconButton>
        <IconButton onClick={handleDelete} color="error"><DeleteIcon/></IconButton>
      </CardActions>
      )}
      <Snackbar 
        open={open} 
        autoHideDuration={6000} 
        onClose={()=>setOpen(false)}>
        <Alert 
          onClose={()=>setOpen(false)} 
          severity="success" 
          sx={{ width: '100%' }}>
          Post Deleted!
        </Alert>
      </Snackbar>
    </Card>
    );
};

export default DiaryItem;