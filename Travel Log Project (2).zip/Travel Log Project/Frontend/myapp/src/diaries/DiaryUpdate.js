import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getPostDetails, postUpdate } from "../api-helpers/helpers";
import {Box,Typography,TextField,FormLabel,Button} from "@mui/material"
import TravelExploreIcon from "@mui/icons-material/TravelExplore";

const DiaryUpdate = () => {
    const [post, setPost] = useState();
    const [inputs, setInputs] = useState({
        title:"",
        description:"",
        location:"",
        imageUrl:"",
    });
    const id = useParams().id;

    useEffect(()=>{
        getPostDetails(id).then((data) => {

         setPost(data.post);

         setInputs({
            title: data.post.title,
            description: data.post.description,
            imageUrl: data.post.image,
            location: data.post.location,
         });
        })
        .catch(err=>console.log(err))
    },[id]);

    const handleChange = (e) => {
        setInputs((prevState) => ({
            ...prevState,
            [e.target.name]: e.target.value,
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(inputs);
        postUpdate(inputs,id).then((data)=>console.log(data)).catch((err)=>console.log(err));
    };
    return( 
        <Box 
            display="flex" 
            flexDirection={"column"} 
            width="100%" 
            height="100%"
        >
        <Box display="flex" margin="auto" padding={2}>
        <Typography fontWeight="bold" variant="h4" fontFamily={"dancing script"}>
                Add Your Travel Expierence
            </Typography>
            <TravelExploreIcon 
            sx={{fontSize:'40px', 
            paddingLeft:1, 
            color: "lightcoral"}}/>
            </Box>
            {post && <form onSubmit={handleSubmit}>
                <Box width={"50%"} padding={3} display="flex" margin="auto" flexDirection={"column"}>
                    <FormLabel sx={{fontFamily: "Roboto Condensed"}}>Title</FormLabel>
                    <TextField
                    onChange={handleChange}
                     name="title" 
                     value={inputs.title} 
                     variant="standard" 
                     margin="normal"/>
                    <FormLabel sx={{fontFamily: "Roboto Condensed"}}>Description</FormLabel>
                    <TextField 
                    onChange={handleChange}
                    name="description" 
                    value={inputs.description} 
                    variant="standard" 
                    margin="normal"/>
                    <FormLabel sx={{fontFamily: "Roboto Condensed"}}>Image Url</FormLabel>
                    <TextField 
                    onChange={handleChange}
                    name="imageUrl" 
                    value={inputs.imageUrl}
                     variant="standard" 
                     margin="normal"/>
                    
                    <FormLabel sx={{fontFamily: "Roboto Condensed"}}>Location</FormLabel>
                    <TextField
                     onChange={handleChange}
                     name="location" 
                     value={inputs.location}
                    variant="standard" 
                    margin="normal"/>
                    <Button  type="submit" variant="contained" color="warning" sx={{mt: 2, width:"50%", margin:"auto", borderRadius: 7}}>Post</Button>
                </Box>
            </form>}
        </Box>
    );
};

export default DiaryUpdate;