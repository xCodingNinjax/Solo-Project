import mongoose, { model, Schema } from "mongoose";

const userSchema = new Schema({
  name: {
    type: String,
    required: true,
    minLength: [1, "Name must be 1 characters"]
  },
  email: {
    type: String,
    required: true,
    unique: true,
    minLength: [1, "Email must be 1 characters"]
  },
  password: {
    type: String,
    required: true,
    minLength: [6, "Password must be 6 character"]
  },
  posts: [{ type: String}],
});

export default model("User", userSchema);

