import mongoose from "mongoose";

const postSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    minLength: [3, "Title must be 3 characters"]
  },
  description: {
    type: String,
    required: true,
    minLength: [3, "Description must be 3 characters"]
  },
  image: {
    type: String,
    required: true,
    minLength: [3, "Image must be 3 characters"]
  },
  location: {
    type: String,
    required: true,
    minLength: [3, "Location must be 3 characters"]
  },
  date: {
    type: Date,
    required: true,
  },
  user: {
    type:String,
    required: true,
    
  },
});

export default mongoose.model("Post", postSchema);
