import React from "react"
import {Box} from "@mui/system";
import { Button, Typography } from "@mui/material";
import {Link} from "react-router-dom"



const Home = () => {
    return <Box position={"relative"} width="100%" height="90vh">
        <img src="/travel.jpg" alt="Travel" width={"100%"} height="80%" />
        <Typography 
        fontWeight="bold"
        fontFamily="Dancing Script, cursive"
        variant="h3" 
        textAlign={"center"}
        width="100%"
        sx={{position: "absolute", top: "0px", color:"white"}}>
        Let's Explore the World Together!
        </Typography>
        <Box 
        width="100%" 
        height="15%" 
        display={"flex"} 
        flexDirection="column">
            <Typography 
            textAlign={"center"} 
            variant="h4" 
            padding={4}
            fontFamily="Roboto Condensed">
                Share Your Adventures

            </Typography>
        </Box>
        <Box  textAlign="center" margin="auto">
            <Button 
            LinkComponent={Link}
            to="/diaries"
            variant="contained" 
            sx={{ml:2}}>
            View Adventures</Button>
        </Box>
    </Box>;
};

export default Home;