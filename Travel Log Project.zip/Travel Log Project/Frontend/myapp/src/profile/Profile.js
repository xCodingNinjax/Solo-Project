import { Typography,Button } from "@mui/material";
import { Box } from "@mui/system";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { getUserDetails } from "../api-helpers/helpers";
import { authActions} from "../store"
import { useNavigate } from "react-router-dom";



const Profile = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [user,setUser] = useState();
    useEffect(() => {
        getUserDetails()
        .then((data)=>setUser(data.user))
        .catch((err)=>console.log(err));
    }, []);
    const handleClick = () =>{
        dispatch(authActions.logout());
        localStorage.removeItem("userId");
        navigate("/");
    }
    return (
        <Box display="flex" flexDirection={"column"}>
        { user && ( 
        <>
            {" "}   
            <Typography textAlign={"center"} variant="h3" fontFamily={"Roboto Condensed"} padding={2}>User Profile</Typography>
            <Typography fontFamily={"Roboto Condensed"} padding={1} textAlign="center">Name: {user.name}</Typography>
            <Typography fontFamily={"Roboto Condensed"} padding={1} textAlign="center">Email: {user.email}</Typography>
            <Button 
            onClick={handleClick}
            sx={{mr:'auto', width: "15%"}} 
            color="warning" 
            variant="contained">Logout</Button>
      </>
     )}
    </Box>
  );
};

export default Profile;